php -f BuildPhar.php && mv TestPhar.phar /home/jhahn/Apps/eclipse-php/workspace/AgilePHP/test/control && chmod 777 /home/jhahn/Apps/eclipse-php/workspace/AgilePHP/test/control/TestPhar.phar
