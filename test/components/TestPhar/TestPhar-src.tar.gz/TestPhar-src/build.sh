php -f BuildPhar.php && mv TestPhar.phar /storage/Apps/eclipse-galileo/workspace/AgilePHP/test/control && chmod 777 /storage/Apps/eclipse-galileo/workspace/AgilePHP/test/control/TestPhar.phar
