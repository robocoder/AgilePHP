<?php
$phar = new Phar('TestPhar.phar');
$phar->addFile('classes/PHTMLRenderer.php');
$phar->addFile('control/Table1Controller.php');
$phar->addFile('control/Table2Controller.php');
$phar->addFile('model/Table1.php');
$phar->addFile('model/Table2.php');
$phar->addFile('view/index.phtml');
$phar->addFile('index.php');
$phar->setStub(file_get_contents('stub.php'));
?>
