<?php
//Phar::mungServer( array( 'REQUEST_URI', 'PHP_SELF', 'SCRIPT_NAME', 'SCRIPT_FILENAME' ) );
//Phar::mount('component.xml', realpath( __DIR__ . '/../components/TestPhar' ) . '/component.xml');
Phar::webPhar( 'TestPhar', 'index.php' );
require 'phar://TestPhar/index.php';
//echo file_get_contents('phar://TestPhar/component.xml');
__HALT_COMPILER();
?>
