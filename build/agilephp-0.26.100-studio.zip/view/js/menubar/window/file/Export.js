AgilePHP.IDE.Menubar.file.Export = function() {

	return new AgilePHP.IDE.Window( 'fileExport', 'fileExport', 'Export' );
}