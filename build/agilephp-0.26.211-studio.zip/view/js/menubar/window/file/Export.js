AgilePHP.Studio.Menubar.file.Export = function() {

	return new AgilePHP.Studio.Window( 'fileExport', 'fileExport', 'Export' );
}