AgilePHP.Studio.Menubar.tools.Settings = function() {

	return new AgilePHP.Studio.Window( 'toolsSettings', 'toolsSettings', 'Settings' );
}