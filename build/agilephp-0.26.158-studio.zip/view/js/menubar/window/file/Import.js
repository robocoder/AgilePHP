AgilePHP.IDE.Menubar.file.Import = function() {

	return new AgilePHP.IDE.Window( 'fileImport', 'fileImport', 'Import' );
}