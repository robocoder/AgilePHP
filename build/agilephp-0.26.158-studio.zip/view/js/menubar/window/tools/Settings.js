AgilePHP.IDE.Menubar.tools.Settings = function() {

	return new AgilePHP.IDE.Window( 'toolsSettings', 'toolsSettings', 'Settings' );
}