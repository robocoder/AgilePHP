AgilePHP.IDE.Taskbar = function() {

	return new Ext.Toolbar({

			id: 'ide-taskbar',
			autoWidth: true,
			style: 'margins: 0 0 0 0',
		    items: [ '-' ]
	});
};