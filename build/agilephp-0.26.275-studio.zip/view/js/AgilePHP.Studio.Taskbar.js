AgilePHP.Studio.Taskbar = function() {

	return new Ext.Toolbar({

			id: 'studio-taskbar',
			autoWidth: true,
			style: 'margins: 0 0 0 0',
		    items: [ '-' ]
	});
};