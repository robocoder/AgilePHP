AgilePHP.Studio.Menubar.file.Import = function() {

	return new AgilePHP.Studio.Window( 'fileImport', 'fileImport', 'Import' );
}