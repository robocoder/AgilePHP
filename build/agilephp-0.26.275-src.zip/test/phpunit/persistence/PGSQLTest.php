<?php
/**
 * @package com.makeabyte.agilephp.test.persistence
 */
class PGSQLTest extends BaseTest { }
?>