<?php 
class SysLogProvider implements LogProvider {

	  public function __construct() { }

	  public function debug( $message ) {
	  	
	  		 echo $message;
	  }
	  
	  public function warn
}
?>